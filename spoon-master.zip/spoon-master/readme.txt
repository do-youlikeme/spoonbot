TUTORIAL INSTALL :

EXTRACT SPOON.ZIP KE FOLDER DOWNLOAD
Nanti ada folder SPOON di folder DOWNLOAD
( /download/SPOON )
Lalu :
1. DOWNLOAD TERMUX
2. BUKA TERMUX lalu ketik termux-setup-storage lalu enter
( Nanti ada notif ijinkan penyimpanan , klik ijinkan )
3. Install Python dengan cara ketik :
pkg install python 
lalu enter
4. Install Module Request dengan cara ketik :
pip install requests 
lalu enter

Cara Jalankan script :
1. Buka Termux
2. Ketik :
cd
lalu enter
Ketik lagi ls lalu enter lagi , nanti keluar storage atau sdcard (sesuai hp)
Misal keluarnya sdcard
ketik sdcard lalu enter , kemudian akses folder scriptnya
ketik downloads/spoon , lalu jalankan script nya
ketik python spoon.py , selesai.
disini kita sudah tau cara akses folder scriptnya, untuk access cepatnya
Buka termux ketik :
cd sdcard/downloads/spoon atau cd storage/downloads/spoon

Untuk Kumpulan Tulisan Komentar Cast/Fanboard isi di file
listkomentarcast.txt untuk Cast
listkomentarfb.txt untuk Fanboard
*catatan jangan gunakan emoji.
*oh ya jumlah komentar cast atau fanboard tergantung list kata di file komentar

Jika kamu punya token lagi, masukan ke file Tokennya.txt

INGAT NAMA FILE JANGAN DI RUBAH ATAU SCRIPT AKAN ERROR.